# Data
marks <- c(70, 85, 90, 60, 75)
names(marks) <- c("A", "B", "C", "D", "E")

# Bar chart
barplot(marks)