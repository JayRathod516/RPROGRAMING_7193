data <- c(10, 20, 30, 40)
labels <- c("A", "B", "C", "D")

# Style 1
pie(data, labels, col = c("red","blue","green","yellow"))

# Style 2
pie(data, labels, main = "Pie Chart")

# Style 3
pie(data, labels, col = rainbow(4))

# Style 4
pie(data, labels, clockwise = TRUE)

# Style 5
pie(data, labels, col = c("pink","cyan","orange","gray"),
    border = "black")