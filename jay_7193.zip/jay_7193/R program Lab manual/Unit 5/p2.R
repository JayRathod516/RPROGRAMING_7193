marks <- c(70, 85, 90, 60, 75)
names(marks) <- c("A", "B", "C", "D", "E")

barplot(marks,
        col = c("red", "blue", "green", "orange", "purple"),
        main = "Student Marks",
        xlab = "Students",
        ylab = "Marks",
        border = "black")