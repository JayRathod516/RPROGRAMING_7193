# seq() - Generate a sequence of numbers
numbers <- seq(1, 10, by = 1)
print(numbers)
# min() - Find the minimum value
minimum_value <- min(numbers)
print(minimum_value)
# max() - Find the maximum value
maximum_value <- max(numbers)
print(maximum_value)
# assign() - Assign a value to a variable using its name
assign("result", c(minimum_value, maximum_value))
# print() - Display the assigned variable
print(result)

