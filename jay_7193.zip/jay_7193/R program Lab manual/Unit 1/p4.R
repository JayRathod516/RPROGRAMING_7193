
# Take input from the user
num <- as.numeric(readline(prompt = "Enter a number: "))
# Check if the number is prime
if (num <= 1) {
  cat(num, "is not a prime number\n")
} else {
  is_prime <- TRUE
  for (i in 2:sqrt(num)) {
    if (num %% i == 0) {
      is_prime <- FALSE
      break
    }
  }
  if (is_prime) {
    cat(num, "is a prime number\n")
  } else {
    cat(num, "is not a prime number\n")
  }
}
