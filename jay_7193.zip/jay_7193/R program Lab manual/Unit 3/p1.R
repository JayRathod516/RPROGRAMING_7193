# Create two 3x3 matrices
A <- matrix(1:9, nrow = 3)
B <- matrix(9:1, nrow = 3)
# Addition
add <- A + B
# Subtraction
sub <- A - B
# Element-wise Multiplication
mul <- A * B
# Element-wise Division
div <- A / B
# Display results
print("Matrix A:")
print(A)
print("Matrix B:")
print(B)
print("Addition:")
print(add)
print("Subtraction:")
print(sub)
print("Multiplication:")
print(mul)
print("Division:")
print(div)