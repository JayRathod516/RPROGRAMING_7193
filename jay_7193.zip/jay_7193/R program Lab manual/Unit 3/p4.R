# Create data frame
student <- data.frame(
  stud_id = c(1, 2, 3),
  stud_name = c("Rahul", "Priya", "Amit"),
  email_id = c("rahul@gmail.com", "priya@gmail.com",
               "amit@gmail.com"),
  mobile_no = c(9876543210, 9123456780, 9988776655)
)
# (a) Display data frame
print("Student Data:")
print(student)
# (b) Display summary
print("Summary of Data Frame:")
summary(student)
#(c)Display structure of data frame
str(student)
#(d) Extract and display only stud_name and mobile_no from data
frame
# Method 1
result <- student[, c("stud_name", "mobile_no")]
print(result)
# Method 2 (direct)
print(student[c("stud_name", "mobile_no")])
