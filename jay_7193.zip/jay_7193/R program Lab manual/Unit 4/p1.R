# First data frame (5 employees)
emp1 <- data.frame(
  emp_id = c(1, 2, 3, 4, 5),
  emp_name = c("Amit", "Neha", "Raj", "Simran", "Karan"),
  salary = c(25000, 30000, 28000, 35000, 27000)
)
# Display first data frame
print("Employee Data Frame 1:")
print(emp1)
# Second data frame (same columns)
emp2 <- data.frame(
  emp_id = c(6, 7),
  emp_name = c("Riya", "Arjun"),
  salary = c(32000, 29000)
)
# Display second data frame
print("Employee Data Frame 2:")
print(emp2)
# Merge both data frames (row-wise)
merged_emp <- rbind(emp1, emp2)
# Display merged data
print("Merged Data Frame:")
print(merged_emp)
