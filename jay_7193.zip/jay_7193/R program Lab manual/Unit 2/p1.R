# Assign values to variables
a <- 15
b <- 4
# Perform arithmetic operations
addition <- a + b
subtraction <- a - b
multiplication <- a * b
division <- a / b
modulus <- a %% b
exponent <- a ^ b
# Display results
cat("Addition:", addition, "\n")
cat("Subtraction:", subtraction, "\n")
cat("Multiplication:", multiplication, "\n")
cat("Division:", division, "\n")
cat("Modulus:", modulus, "\n")
cat("Exponent:", exponent, "\n")
