x <- 10 # Using <-
y = 20 # Using =
30 -> z # Using ->
# Using assign() function
assign("a", 40)
# Display values
print(x)
print(y)
print(z)
print(a)