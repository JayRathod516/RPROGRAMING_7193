lower <- letters
upper <- LETTERS
first_10_lower <- lower[1:10]
last_10_upper <- upper[17:26]
mid_upper <- upper[22:24]
print(first_10_lower)
print(last_10_upper)
print(mid_upper)