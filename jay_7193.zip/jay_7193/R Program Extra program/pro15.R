n=40
o=20
p=30
if(n>o&p>o){
  print("both conditions are true")
}else{
  print("anyone/both conditions is/are false")
}

