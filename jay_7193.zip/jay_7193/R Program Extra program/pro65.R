x = c("A","B","C","D","E","F","G","H","I")
y = c(25,50,75,100,125,150,175,200,225)

barplot(y,names.arg = x,col =rainbow(length(x)),density = 50,width=c(1,2,3,2,1,2,3,2,1),
        horiz = TRUE)