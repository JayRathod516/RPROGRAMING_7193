no1 <- readline(prompt = "Enter your 1st no: ")
no2 <- readline(prompt = "Enter your 2nd no: ")
no1 <- as.numeric(no1)
no2 <- as.numeric(no2)
no3 <- no1 * no2


print(paste("Enter", no3, "elements:"))
ele <- scan(n = no3)

m1=matrix(ele,nrow = no1 ,ncol = no2)
print("Matrix elements are:")
for (i in 1:nrow(m1)) {
  for (j in 1:ncol(m1)) {
    print(paste("m1[", i, ",", j, "] =", m1[i, j]))
  }
}
print("==================")
print(m1)