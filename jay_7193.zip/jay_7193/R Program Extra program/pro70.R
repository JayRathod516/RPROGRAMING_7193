str(airquality)
Temperature<-airquality$Temp
hist(Temperature)

hist(Temperature,
     main="Maximum daily temperature at LA Guardia Airport",
     xlab="temperature in dagrees fahrenheit",
     xlim=c(50,100),
     col="darkmagenta",
     freq= FALSE)
