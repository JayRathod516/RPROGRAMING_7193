i=8
j=9

if(i>j){
  print("a is max")
}else{
  print("b is max")
}

