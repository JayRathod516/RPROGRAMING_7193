v=c(25,10,40,5,30)

print(sort(v))

print("==========")

print(sort(v,decreasing = TRUE))