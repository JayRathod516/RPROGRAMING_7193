name=readline(prompt = "Enter your name : ")
age=readline(prompt = "Enter your age : ")
age=as.numeric(age)
cat("Name : ",name,"\n")
cat("Age : ",age,"\n")

cat("R Version Information:\n")
print(version)
