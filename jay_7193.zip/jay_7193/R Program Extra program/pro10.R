n1=5
n2=2

sum=n1+n2
sub=n1-n2
mul=n1*n2
div=n1/n2

print(paste("sum is : ",sum))
print(paste("sum is : ",sub))
print(paste("sum is : ",mul))
print(paste("sum is : ",div))