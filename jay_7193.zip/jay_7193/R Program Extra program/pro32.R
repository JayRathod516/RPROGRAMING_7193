m1=matrix(c(1,2,3,4,5,6),nrow = 2 ,ncol = 3)
m2=matrix(c(7,8,9),nrow = 1 ,ncol = 3)
m3=rbind(m1,m2)
print(m3)