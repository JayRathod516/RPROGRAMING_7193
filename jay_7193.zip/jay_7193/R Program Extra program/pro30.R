m=matrix(c(1,2,3,4,5,6),nrow=2,ncol=3)
colnames(m)=c("c1","c2","c3")
rownames(m)=c("r1","r2")
print(m)