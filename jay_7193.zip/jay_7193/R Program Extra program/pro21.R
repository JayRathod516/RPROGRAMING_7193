a=c(5,3,8,2,9,1,3,NA,7)

asc=sort(a)
print(asc)

des=sort(a,decreasing=TRUE,na.last=TRUE)

print(des)