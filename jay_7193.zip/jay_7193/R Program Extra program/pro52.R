df1 <- data.frame(
Name = c("Alice", "Bob"),
Age = c(25, 30),
Score = c(80, 75)
)
df2 <- data.frame(
Height = c(160, 175),
Weight = c(55, 70)
)
cat("Dataframe 1:\n")
print(df1)
cat("\nDataframe 2:\n")
print(df2)

combined_df <- cbind(df1, df2)
cat("\nCombined Dataframe:\n")
print(combined_df)
