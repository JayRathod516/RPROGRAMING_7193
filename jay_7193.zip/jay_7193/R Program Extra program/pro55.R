a = c(17,2,8,13,1,22,32,15,5,27,40,50)
b = c("jan","fab","mar","apr","may","jun","jul","aug","sep","oct","nev","dec")

barplot(a, names.arg = b, xlab = "month",
        ylab = "articals", col = "blue",
        main = "artical chart",
        cex.main = 1.5, cex.lab = 1.2, cex.axis = 1)
text(
  x = barplot(a, names.arg = b, col = "darkgreen",
              ylim = c(0,max(a)*1.2)),
              y = a+1, labels = a, pos = 3, cex = 1.2,
              col = "lightgreen")