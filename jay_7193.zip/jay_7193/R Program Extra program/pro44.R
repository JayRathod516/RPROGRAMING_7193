friend.data <- data.frame(
  friend_id = c(1:5),
  friend_name = c("Sachin", "Sourav",
                  "Dravid", "Sehwag",
                  "Dhoni"),
  stringsAsFactors = FALSE
)
friend.data$location <- c("Kolkata", "Delhi",
                          "Bangalore", "Hyderabad",
                          "Chennai")
resultant <- friend.data
print(resultant)