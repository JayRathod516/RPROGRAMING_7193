k=10
l=11

if(k==l){
  print("both are same")
}else if(k>l){
  print("k is max")
}else{
  print("l is max")
}

