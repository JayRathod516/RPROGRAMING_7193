A <- c(9,2,5,6,7)

barplot(A, xlab = "x-axis", ylab = "y-axis" ,col = "white" ,main = "bar-chart")
