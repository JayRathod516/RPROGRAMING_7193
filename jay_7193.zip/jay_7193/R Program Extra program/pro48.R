Products <- data.frame(
  Product_ID = c(101, 102, 103),
  Product_Name = c("T-Shirt", "Jeans", "Shoes"),
  Price = c(15.99, 29.99, 49.99),
  Stock = c(50, 30, 25)
)
cat("Existing dataframe (Products):\n")
print(Products)
Discount <- c(5, 10, 8)

Products <- cbind(Products, Discount)
colnames(Products)[ncol(Products)] <- "Discount"
cat("\nUpdated dataframe after adding a new column 'Discount':\n")
print(Products)