name <- readline(prompt = "Enter your name: ")
age  <- readline(prompt = "Enter your age: ")

age <- as.numeric(age)

print(paste("hello ",name))
print(paste("next year your age is ",age+1))