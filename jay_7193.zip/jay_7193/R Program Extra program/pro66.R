x = c("A","B","C","D","E","F","G","H","I")

y = c(5,10,15,20,25,30,35,40,45)

setwd("C:/Users/Raj modhvadiya/OneDrive/Documents/R Program/CW")

png(file = "pro66_barplot.png")


barplot(y,names.arg = x,xlab = "R audience",
        ylab = "count", col =rainbow(length(x)),
        density = 50,width=c(1,2,3,2,1,2,3,2,1),
        col.axis = "darkgreen",
        col.lab = "lightgreen",
        border=rainbow(length(x)))
        
dev.off()
