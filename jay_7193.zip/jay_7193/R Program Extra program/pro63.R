b = c("apple","banana","oranges","grapes","mangoes")
a = c(10,20,15,25,30)

barplot(a, names.arg = b, xlab = "fruit type",
        ylab = "quantity sold", col = "blue",
        main = "weekly fruit sales",
        cex.main = 1.5, cex.lab = 1.2, cex.axis = 1)
text(
  x = barplot(a, names.arg = b, col = "darkgreen",
              ylim = c(0,max(a)*1.2)),
  y = a+1, labels = a, pos = 3, cex = 1.2,
  col = "lightgreen")