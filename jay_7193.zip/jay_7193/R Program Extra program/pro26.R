names <- c("Vipul", "Raj", "Singh", "Jhala")
sorted_names <- sort(names)
print(sorted_names)