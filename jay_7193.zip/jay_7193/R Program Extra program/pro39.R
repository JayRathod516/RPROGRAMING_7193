#write a program that do arithmetic operations
n1=as.numeric(readline(prompt = "enter a number for n1 : "))
n2=as.numeric(readline(prompt = "enter a number for n2 : "))

cat("addition",n1 + n2,"\n")
cat("Subtraction:",n1 - n2,"\n")
cat("Multiplication:",n1 * n2,"\n")

if (n2 != 0) {
  cat("Division:",n1 / n2,"\n")
} else {
  cat("Division: Not possible (division by zero)\n")
}

