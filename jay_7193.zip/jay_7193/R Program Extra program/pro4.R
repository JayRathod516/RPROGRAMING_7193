e=4
f=5
g=e>f
print(g)
print(class(g))
print(typeof(g))