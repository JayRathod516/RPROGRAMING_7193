v=c(19,23,11,5,16,21,32,14,19,27,39,120,40,70,90)
m=hist(v,xlab = "weight",
     col = "lightyellow",
     border = "yellow",breaks = 5)
text(m$mids,m$counts,labels = m$counts,adj = c(0.5,-0.5))