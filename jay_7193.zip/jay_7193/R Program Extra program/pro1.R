a=0
print(class(a))
print(typeof(a))