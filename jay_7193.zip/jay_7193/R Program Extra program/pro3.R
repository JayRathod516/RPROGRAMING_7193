c=as.integer(2)
print(class(c))
print(typeof(c))
d=3L
print(class(d))
print(typeof(d))